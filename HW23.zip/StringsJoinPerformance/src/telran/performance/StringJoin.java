package telran.performance;

public interface StringJoin {
	public String join(String delimiter, String[] array);
}
